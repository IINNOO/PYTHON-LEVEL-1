print("This programme is a simple calculator that will multiply two numbers together")
first_Num = int((input("Please enter your first number")))
second_Num = int((input("Please enter your second number")))
total = firstNum*second_Num
print(f"The product of {first_Num}*{second_Num}={total}"
)

